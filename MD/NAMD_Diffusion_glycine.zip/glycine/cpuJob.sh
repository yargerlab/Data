#!/bin/bash
#SBATCH --job-name=glyn-namd
#SBATCH --time=24:00:00
#SBATCH --ntasks=16
#SBATCH -p circe

module load compilers/intel/2013_cluster_xe
export I_MPI_PMI_LIBRARY=/usr/lib64/libpmi.so
namd=~/NAMD_2.10_Source/Linux-x86_64-g++/namd2

#/usr/bin/srun -n 16 $namd nvt.conf > nvt.out
#/usr/bin/srun -n 16 $namd npt.conf > npt.out

i=0
nrun=20
while [ $i -le $nrun ]
do
    awk -v i=$i '{if($1=="outputname"){print "outputname       nve-"i}else{print $0};}' nve.template > nve.conf
    /usr/bin/srun -n 16 $namd nve.conf > nve-$i.out
    i=`expr $i + 1`
done