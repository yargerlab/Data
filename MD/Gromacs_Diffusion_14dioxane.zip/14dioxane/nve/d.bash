#!/bin/bash

gmx msd -f nve-0.trr -s nve-0.tpr -trestart 2.0 -o 0-msd.xvg && \
gmx msd -f nve-1.trr -s nve-1.tpr -trestart 2.0 -o 1-msd.xvg && \
gmx msd -f nve-2.trr -s nve-2.tpr -trestart 2.0 -o 2-msd.xvg && \
gmx msd -f nve-3.trr -s nve-3.tpr -trestart 2.0 -o 3-msd.xvg && \
gmx msd -f nve-4.trr -s nve-4.tpr -trestart 2.0 -o 4-msd.xvg && \
gmx msd -f nve-5.trr -s nve-5.tpr -trestart 2.0 -o 5-msd.xvg && \
gmx msd -f nve-6.trr -s nve-6.tpr -trestart 2.0 -o 6-msd.xvg && \
gmx msd -f nve-7.trr -s nve-7.tpr -trestart 2.0 -o 7-msd.xvg && \
gmx msd -f nve-8.trr -s nve-8.tpr -trestart 2.0 -o 8-msd.xvg && \
gmx msd -f nve-9.trr -s nve-9.tpr -trestart 2.0 -o 9-msd.xvg && \
gmx msd -f nve-10.trr -s nve-10.tpr -trestart 2.0 -o 10-msd.xvg && \
gmx msd -f nve-11.trr -s nve-11.tpr -trestart 2.0 -o 11-msd.xvg && \
gmx msd -f nve-12.trr -s nve-12.tpr -trestart 2.0 -o 12-msd.xvg && \
gmx msd -f nve-13.trr -s nve-13.tpr -trestart 2.0 -o 13-msd.xvg && \
gmx msd -f nve-14.trr -s nve-14.tpr -trestart 2.0 -o 14-msd.xvg && \
gmx msd -f nve-15.trr -s nve-15.tpr -trestart 2.0 -o 15-msd.xvg && \
gmx msd -f nve-16.trr -s nve-16.tpr -trestart 2.0 -o 16-msd.xvg && \
gmx msd -f nve-17.trr -s nve-17.tpr -trestart 2.0 -o 17-msd.xvg && \
gmx msd -f nve-18.trr -s nve-18.tpr -trestart 2.0 -o 18-msd.xvg && \
gmx msd -f nve-19.trr -s nve-19.tpr -trestart 2.0 -o 19-msd.xvg