#!/bin/bash

xmgrace 0-msd.xvg 1-msd.xvg 2-msd.xvg 3-msd.xvg 4-msd.xvg 5-msd.xvg \
        6-msd.xvg 7-msd.xvg 8-msd.xvg 9-msd.xvg 10-msd.xvg 11-msd.xvg \
        12-msd.xvg 13-msd.xvg 14-msd.xvg 15-msd.xvg 16-msd.xvg 17-msd.xvg \
        18-msd.xvg 19-msd.xvg