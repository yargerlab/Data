#!/bin/bash
#SBATCH --job-name=glyn-lm
#SBATCH --time=20:00:00
#SBATCH --ntasks=8
#SBATCH -p circe

module purge
module load compilers/intel/2015_cluster_xe
export I_MPI_PMI_LIBRARY=/usr/lib64/libpmi.so
lammps=/home/g/gmgray2/lammps-10Aug15/src/lmp_intel_cpu

#srun -n 8 $lammps < nvt.in > nvt.out
#srun -n 8 $lammps < npt.in > npt.out
srun -n 8 $lammps < nve.in > nve.out