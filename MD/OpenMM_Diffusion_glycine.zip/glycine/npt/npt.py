##########################################################################
#
# Simulated the NPT ensemble
#
from __future__ import print_function
from simtk.openmm.app import *
from simtk.openmm import *
from simtk import unit
from sys import stdout

temp = 300.0
timestep = 2.0
cutoff = 1.2
printfreq = 1000
nsteps = 50000
nsav_rst = 50000
gamma = 5

#print('Checking for CUDA...')
#platform = Platform.getPlatformByName('CUDA')
#properties = {'CudaPrecision': 'mixed'}

psf = CharmmPsfFile('npt/glyn-solv.psf')
pdb = PDBFile('npt/glyn-solv.pdb')

params = CharmmParameterSet('../top_all36_cgenff.rtf','../par_all36_cgenff.prm','../toppar_water_ions.str')

coords = pdb.positions

min_crds = [coords[0][0], coords[0][1], coords[0][2]]
max_crds = [coords[0][0], coords[0][1], coords[0][2]]

for coord in coords:
    min_crds[0] = min(min_crds[0], coord[0])
    min_crds[1] = min(min_crds[1], coord[1])
    min_crds[2] = min(min_crds[2], coord[2])
    max_crds[0] = max(max_crds[0], coord[0])
    max_crds[1] = max(max_crds[1], coord[1])
    max_crds[2] = max(max_crds[2], coord[2])
    
a = ( max_crds[0]-min_crds[0] ) - ( 0.1 * unit.nanometers )
b = ( max_crds[1]-min_crds[1] ) - ( 0.1 * unit.nanometers )
c = ( max_crds[2]-min_crds[2] ) - ( 0.1 * unit.nanometers )

psf.setBox(a,b,c)

print ('Setting up system...')
system = psf.createSystem(params,nonbondedMethod=PME, 
    nonbondedCutoff=cutoff*unit.nanometers, constraints=HBonds, rigidWater=True, 
    ewaldErrorTolerance=0.00005)

print('Choosing integrator...')
integrator = LangevinIntegrator(temp*unit.kelvin, gamma/unit.picoseconds, 
                                timestep*unit.femtoseconds)
integrator.setConstraintTolerance(0.000001)
system.addForce(MonteCarloBarostat(1*unit.atmospheres, temp*unit.kelvin, 25))

print('Establishing simulation context...')
simulation = Simulation(psf.topology, system, integrator, platform, 
                        properties)
simulation.context.setPositions(pdb.positions)

print('Minimizing...')
simulation.minimizeEnergy()
positions = simulation.context.getState(getPositions=True).getPositions()
PDBFile.writeFile(simulation.topology, positions, open('npt/min.pdb', 'w'))

simulation.context.setVelocitiesToTemperature(float(temp)*unit.kelvin)

simulation.reporters.append(CheckpointReporter('npt/npt.chk', nsav_rst))
simulation.reporters.append(DCDReporter('npt/npt.dcd', printfreq))
simulation.reporters.append(StateDataReporter(stdout, printfreq, step=True, 
                                              time=True, potentialEnergy=True, 
                                              kineticEnergy=True, totalEnergy=True, 
                                              temperature=True, density=True, speed=True, 
                                              totalSteps=printfreq, separator='\t'))

print('Running Production...')
simulation.step(nsteps)
