#!/bin/bash
#SBATCH --job-name=glyn-omm
#SBATCH --time=24:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --gres=gpu:1 -C "gpu_K20"
#SBATCH -p cuda

module purge
module load compilers/intel/2015_cluster_xe apps/cuda/6.5.14

export OPENMM_CUDA_COMPILER=`which nvcc`
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/apps/cuda/6.5.14/lib
export PATH=/home/g/gmgray2/Anaconda-2.3.0/bin:$PATH
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/g/gmgray2/Anaconda-2.3.0/lib

py=/home/g/gmgray2/Anaconda-2.3.0/bin/python

$py nvt.py > nvt.out
$py npt.py > npt.out

i=0
nrun=20
while [ $i -lt $nrun ]
do
    $py nve.py $i > nve.out
    i=`expr $i + 1`
done