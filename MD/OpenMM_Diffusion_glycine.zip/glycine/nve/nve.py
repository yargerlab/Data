##########################################################################
#
# Simulate the NVE ensemble
#
from __future__ import print_function
from simtk.openmm.app import *
from simtk.openmm import *
from simtk import unit
from sys import stdout, argv

if len(argv) != 2:
    print ('Incorrect number of command line arguments!')
    exit()

i = argv[1]

temp = 300
nsav_crd = 1000
nsav_rst = 150000
nprint = 1000
nstep = 150000
cutoff = 1.2

#print('Checking for CUDA...')
#platform = Platform.getPlatformByName('CUDA')
#properties = {'CudaPrecision': 'mixed'}

psf = CharmmPsfFile('npt/glyn-solv.psf')
pdb = PDBFile('npt/min.pdb')

params = CharmmParameterSet('../top_all36_cgenff.rtf','../par_all36_cgenff.prm','../toppar_water_ions.str')

coords = pdb.positions

min_crds = [coords[0][0], coords[0][1], coords[0][2]]
max_crds = [coords[0][0], coords[0][1], coords[0][2]]

for coord in coords:
    min_crds[0] = min(min_crds[0], coord[0])
    min_crds[1] = min(min_crds[1], coord[1])
    min_crds[2] = min(min_crds[2], coord[2])
    max_crds[0] = max(max_crds[0], coord[0])
    max_crds[1] = max(max_crds[1], coord[1])
    max_crds[2] = max(max_crds[2], coord[2])
    
a = max_crds[0]-min_crds[0]
b = max_crds[1]-min_crds[1]
c = max_crds[2]-min_crds[2]

psf.setBox(max_crds[0]-min_crds[0],
           max_crds[1]-min_crds[1],
           max_crds[2]-min_crds[2],
           )

print ('Setting up system...')
system = psf.createSystem(params,nonbondedMethod=PME, 
    nonbondedCutoff=cutoff*unit.nanometers, constraints=HBonds, rigidWater=True, 
    ewaldErrorTolerance=0.00005)

print('Choosing integrator...')
integrator = VerletIntegrator(2.0*unit.femtoseconds)

print('Establishing simulation context...')
simulation = Simulation(psf.topology, system, integrator, platform, 
                        properties)
simulation.context.setPositions(pdb.positions)

with open('npt/npt.chk', 'rb') as f: simulation.context.loadCheckpoint(f.read())
simulation.context.setVelocitiesToTemperature(float(temp)*unit.kelvin)
simulation.reporters.append(CheckpointReporter('nve/nve-'+str(i)+'.chk', nsav_rst))
simulation.reporters.append(DCDReporter('nve/nve-'+str(i)+'.dcd', nsav_crd))
simulation.reporters.append(StateDataReporter(stdout, nprint, step=True, 
                                              time=True, potentialEnergy=True, 
                                              kineticEnergy=True, totalEnergy=True, 
                                              temperature=True, density=True, speed=True, 
                                              totalSteps=nprint, separator='\t'))
print('Running Production...')
simulation.step(nstep)

