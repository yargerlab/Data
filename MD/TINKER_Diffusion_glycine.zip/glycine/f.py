#!/usr/bin/env python 

f = open('solv.xyz','r')
f2 = open('solv-2.xyz','w')
for f0 in f:
    if len(f0.split())>1:
        if f0.split()[1] == 'O':
            f0 = f0.replace(' 0 ',' 1 ')
            f2.write(f0)
        elif f0.split()[1] == 'H':
            f0 = f0.replace(' 0 ',' 2 ')
            f2.write(f0)
        else:
            f2.write(f0)
f.close()
f2.close()
