#!/bin/bash
#SBATCH --job-name=glyn-tn
#SBATCH --time=14:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=8
#SBATCH --constraint=cpu_xeon

export I_MPI_PMI_LIBRARY=/usr/lib64/libpmi.so

dyna=/home/g/gmgray2/bin-linux64/dynamic

$dyna glyn-solv.xyz_2 50000 2.0 2.0 4 300 1.0 > npt.out
$dyna glyn-solv.xyz_2 100000 2.0 2.0 1 > nve.out