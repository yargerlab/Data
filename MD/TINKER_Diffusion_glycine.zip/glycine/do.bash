#!/bin/bash

i=0
nrun=20

while [ $i -lt $nrun ]
do
    touch $i
    \rm -r $i
    mkdir $i
    cp glyn-solv.xyz_2 glyn-solv.dyn glyn-solv.key $i
    i=`expr $i + 1`
done