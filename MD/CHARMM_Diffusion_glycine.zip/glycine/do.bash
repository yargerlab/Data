#!/bin/bash 

charmm=/Users/geoffreygray/charmm/c41a1/exec/osx/charmm

i=0
nrun=20
while [ $i -lt $nrun ]
do
    $charmm irun=$i -i diffusion.inp > $i.out
    i=`expr $i + 1`
done
